package com;

public class book {
	private String title;
	private  String author;
	private int cost;
public book() {
	
}
public book(String title1,String author,int cost) {
	title=title1;
	this.author=author;
	this.cost=cost;
}
public void Settitle(String title) {
	this.title=title;
}
public String Gettitle() {
	return title;
}
public void Setauthor(String author) {
	this.author=author;
}
public String Getauthor() {
	return author;
}
public void Setcost(int cost) {
	this.cost=cost;
}
public int Getcost() {
	return cost;
}
public void display() {
	System.out.println("name of the book:"+Gettitle());
	System.out.println("name of the author:"+Getauthor());
	System.out.println("cost of the book:"+Getcost());
}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("bookdetails");
book m=new book();
m.Settitle("avengers");
m.Setauthor("tony stark");
m.Setcost(500);
m.display();
	}

}
