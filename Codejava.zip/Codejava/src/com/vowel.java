package com;
import java.util.Scanner;
public class vowel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Scanner sc=new Scanner(System.in); 
    	System.out.println("enter a character:");
    	char ch = sc.next().charAt(0);
    	switch(ch) {
    	case 'a':
    	System.out.println("vowel");
    	case 'A':
    	System.out.println("vowel");
    	case 'e':
        System.out.println("vowel");
        case 'E':
        System.out.println("vowel");
        case 'i':
        System.out.println("vowel");
        case 'I':
        System.out.println("vowel");
        case 'o':
        System.out.println("vowel");
        case 'O':
        System.out.println("vowel");
        case 'U':
        System.out.println("vowel");
        case 'u':
        System.out.println("vowel");
        break;
        default:
        System.out.println("not");
    	}
    }
	}


