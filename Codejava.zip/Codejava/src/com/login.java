package com;
import java.util.Scanner;
public class login {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Scanner sc=new Scanner (System.in);
    System.out.println("enter your username");
    String a=sc.next();
    System.out.println("enter you password");
    String b=sc.next();
    String username="admin";
    String password="admin123";
    if (a.equals(username)) {
    	if(b.equals(password)) {
    		System.out.println("login succesful");
    	}
    	else {
    		System.out.println("password is invalid ");
    	}
    }
    	else {
    	 System.out.println("username is invalid");    
    	}
    }
    
	}


