package com;

public class multisubsub extends multisub{
	public void car2() {
		System.out.println("bmwm5");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		multisubsub mss=new multisubsub();
		mss.car2();
		mss.car1();
		mss.car();

	}

}
