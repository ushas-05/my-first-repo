package com;

public class primenum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      for(int num=2;num<=1000;num++) {
    	  boolean prime=true;
    	  for(int i=2;i<=num/2;i++) {
    	      if(num%i==0) {
    	       prime=false;
    	       break;
    	}
    }
	
    if(prime){
        System.out.println(num);
    }

}
	}
}