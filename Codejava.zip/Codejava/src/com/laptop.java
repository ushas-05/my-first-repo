package com;

public class laptop {
	private String laptopname;
	private String laptopmodel;
	private int ram;
	private int memory;
	private int cost;
public laptop(){
	
	
}
public laptop(String laptopname1,String laptopmodel,int ram,int memory,int cost) {
	     laptopname=laptopname1;
	     this.laptopmodel=laptopmodel;
	     this.ram=ram;
	     this.memory=memory;
	     this.cost=cost;

}
public void setlaptopname(String laptopname) {
	this.laptopname=laptopname;
}
public String getlaptopname() {
	return laptopname;
}
public void setlaptopmodel(String laptopmodel) {
	this.laptopmodel=laptopmodel;
}
public String getlaptopmodel() {
	return laptopmodel;
}
public void setram(int ram) {
	this.ram=ram;
}
public int getram() {
	return ram;
}
public void setmemory(int memory) {
	this.memory=memory;
}
public int getmemory() {
	return memory;
}
public void setcost(int cost) {
	this.cost=cost;
}
public int getcost() {
	return cost;
}
public void display() {
	System.out.println("name of the laptop:"+getlaptopname());
	System.out.println("name of the model:"+getlaptopmodel());
	System.out.println("how much of ram does laptop contain:"+getram());
	System.out.println("how much of memeory does laptop stores:"+getmemory());
	System.out.println("how much of cost:"+getcost());
	
	
}

	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   System.out.println("Laptop details");
   laptop l=new laptop();
   l.setlaptopname("Apple");
   l.setlaptopmodel("macbook");
   l.setram(8);
   l.setmemory(8);
   l.setcost(80000);
   l.display();
   System.out.println("---------");
   System.out.println("Laptop details");
   l.setlaptopname("hp");
   l.setlaptopmodel("elite book");
   l.setram(16);
   l.setmemory(8);
   l.setcost(70000);
   l.display();
   
	}

}
