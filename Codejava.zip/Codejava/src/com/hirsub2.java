package com;

public class hirsub2 extends hirsub1{
public void car2() {
	System.out.println("bmwm7");
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
      hirsub2 hs2=new hirsub2();
      hs2.car2();
      hs2.car1();
      hs2.car();
      
	}

}
