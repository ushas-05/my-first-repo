package com;

public class Final implements e {
	public void c() {
		System.out.println("c");
	}
	public void d() {
		System.out.println("d");
		
	}
	public void e() {
		System.out.println("e");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Final f=new Final();
		f.c();
		f.d();
		f.e();

	}

}
