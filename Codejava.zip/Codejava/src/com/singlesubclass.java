package com;

public class singlesubclass extends singlesuperclass {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		singlesubclass ssc=new singlesubclass();
		ssc.a=10;
		ssc.b=20;
		ssc.display();

	}

}
