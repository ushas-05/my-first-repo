package com;

public class staticandnonstatic {
	static String company_name="tcs";
	static String company_location="hyd";
	String emp_name;
	int emp_id;
	int emp_salary;
	public static void developer() {
		System.out.println("designation is developer");
	}
	public  static void tester() {
	 System.out.println("designation is tester");
		 
	 
	 
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     System.out.println(company_name);
     System.out.println(company_location);
     staticandnonstatic san=new staticandnonstatic();
     san.emp_name="ram";
     System.out.println(san.emp_name);
     san.emp_id=638;
     System.out.println(san.emp_id);
     san.emp_salary=100000;
     System.out.println(san.emp_salary);
     tester();
     System.out.println("--------------");
     staticandnonstatic san1=new staticandnonstatic();
     System.out.println(company_name);
     System.out.println(company_location);
     san1.emp_name="sita";
     System.out.println(san1.emp_name);
     san1.emp_id=1234;
     System.out.println(san1.emp_id);
     san1.emp_salary=200000;
     System.out.println(san1.emp_salary);
     developer();
     
	}

}
