package com;

public class wihreturntypewithargument {
public static int mul(int a,int b) {
	return a*b;
}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int result=mul(13,6);
		System.out.println(result);

	}

}
