package com;

public abstract class demo {
	abstract public void run();
	
	}


