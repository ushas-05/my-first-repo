package com;

public class mor extends overriding{
@Override
public void whatsappversion() {
	System.out.println("version 2.0--->single tick+double tick+blue ticks+ meta ai");
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		mor m=new mor();
		m.whatsappversion();

	}

}
