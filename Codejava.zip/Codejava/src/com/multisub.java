package com;

public class multisub extends multisuper {
	public void car1() {
		System.out.println("bmw3");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		multisub ms=new multisub();
		ms.car1();
		ms.car();

	}

}
