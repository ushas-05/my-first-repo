package com;
import java.util.Scanner;
public class vowelornot {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="usha";
		int count=0;
		for(int i=0;i<str.length();i++) {
		char ch=Character.toLowerCase(str.charAt(i));
		if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u') 
			count++;
		}
		System.out.println(count);
			
		}
	}

