package com;

public class overriding extends methodoverriding {
@Override
public void whatsappversion() {
	System.out.println("version 2-->singleticks+doubleticks");
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
     overriding or=new overriding();
     or.whatsappversion();
	}

}
