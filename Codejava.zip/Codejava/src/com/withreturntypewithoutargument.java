package com;

public class withreturntypewithoutargument {
public static int div() {
	int a=100;int  b=20;
	int result=a/b;
	return result;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
          int hy=div();
          System.out.println(hy);
	}

}
