package com;

public class methodoverloading {
  public static void add(int a,int b) {
	  System.out.println(a+b);
	  
  }
  public static void add(float a,float b) {
	  System.out.println(a+b);
  }
  public static void add(double a,double b) {
	  System.out.println(a+b);
  }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		add(10,20);
		add(12.0,13.0);
		add(78.0,45.0);

	}

}
