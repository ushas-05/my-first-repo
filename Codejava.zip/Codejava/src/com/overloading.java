package com;

public class overloading {
public static void payment(int num,int cvv,int bal) {
	System.out.println("paid through debit card");
	
}
public static void payment(int num,int exp) {
	System.out.println("paid through credit card");
	
}
public static void payment(int cash) {
	System.out.println("paid through cod");
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		payment(89,678,43578);
		payment(45,894);
		payment(250);

	}

}
