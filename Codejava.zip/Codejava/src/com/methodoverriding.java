package com;

public class methodoverriding {
   public void whatsappversion() {
	   System.out.println("version1-->only single ticks");
   }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
      
	

	}

}
