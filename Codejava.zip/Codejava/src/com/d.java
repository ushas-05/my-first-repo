package com;

public interface d extends c{
	void d();


	
}
