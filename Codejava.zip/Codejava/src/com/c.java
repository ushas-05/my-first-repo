package com;

public interface c {
	void c();
		
	

	

	}


