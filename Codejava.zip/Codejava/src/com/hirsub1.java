package com;

public class hirsub1 extends hirsuper{
public void car1() {
	System.out.println("bmwm5");
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
     hirsub1 hs1=new hirsub1();
     hs1.car1();
     hs1.car();
	}

}
