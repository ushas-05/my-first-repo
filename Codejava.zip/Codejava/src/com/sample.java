package com;

public class sample extends demo{
@Override
	public void run() {
	
		System.out.println("running");
	}
public static void main(String[]args) {
	sample s=new sample();
	s.run();
	
}
}

