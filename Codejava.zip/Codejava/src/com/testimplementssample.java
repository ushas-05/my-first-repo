package com;

public class testimplementssample {
public void sample() {
	System.out.println("sample book");
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		testimplementssample t=new testimplementssample();
		t.sample();

	}

}
