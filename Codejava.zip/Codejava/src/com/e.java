package com;

public interface e extends d {
	void e();

	

	}

