package com;

public class naturalnum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  int start=1;
  int end=1000;
  while(start<=end) {
	  System.out.println(start);
	  start++;
  }
	}

}
