package com;

public class dowhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		   int n = 5;
	        int start = 2;
	        boolean isPrime = true;

	        do {
	            if (n % start == 0) {
	                isPrime = false;
	                break;
	            }
	            start++;
	        } while (start <= n / 2);

	        if (isPrime && n > 1) {
	            System.out.println(n + " is prime");
	        } else {
	            System.out.println(n + " is not prime");
	        }
	    }
	}
