package com;

public class hirsuper {
	public void car() {
		System.out.println("bmwm3");
	}
   
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		hirsuper hs=new hirsuper();
		hs.car();
		

	}

}
