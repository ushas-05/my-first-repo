package com;

public class multisuper {
public void car() {
	System.out.println("bmw1");
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		multisuper m=new multisuper();
		m.car();

	}

}
